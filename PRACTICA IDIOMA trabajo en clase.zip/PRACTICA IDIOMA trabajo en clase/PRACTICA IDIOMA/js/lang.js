// Traducciones en español e inglés
const translations = {
    es: {
        optionMenu1: "Inicio",
        optionMenu2: "Nosotros",
        optionMenu3: "Slogan",
        optionMenu4: "Cafés",
        title1: "El mejor café de Costa Rica",
        title2: "Nosotros",
        title3: "Visión",
        title4: "Misión",
        title5: "Valores",
        title6: "El mejor café de Costa Rica",
        title7: "Cafés",
        Cafe1: "Molido clásico",
        Cafe2: "Reserva especial",
        Cafe3: "Molido tueste claro",
        Cafe4: "Grano entero clásico",
        Cafe5: "Molido cielo",
        Cafe6: "Café negro",
        title8: "Empleados",
        p2: "Conozca nuestros empleados mediante esta lista",
        Footer: "Grupo AgroIndustrial NUMAR S.A. © 2021 Café 1820. Todos los derechos reservados",
    },
    en: {
        optionMenu1: "Home",
        optionMenu2: "About Us",
        optionMenu3: "Slogan",
        optionMenu4: "Coffee",
        title1: "The Best Coffee in Costa Rica",
        title2: "About Us",
        title3: "Vision",
        title4: "Mission",
        title5: "Values",
        title6: "The Best Coffee in Costa Rica",
        title7: "Coffees",
        Cafe1: "Classic Ground",
        Cafe2: "Special Reserve",
        Cafe3: "Light Roast Ground",
        Cafe4: "Classic Whole Bean",
        Cafe5: "Sky Blend Ground",
        Cafe6: "Black Coffee",
        title8: "Employees",
        p2: "Meet our employees through this list",
        Footer: "NUMAR AgroIndustrial Group S.A. © 2021 Café 1820. All rights reserved",
    }
};

// Función para aplicar el idioma seleccionado
function applyLanguage(lang) {
    document.documentElement.lang = lang;
    document.querySelectorAll("[data-translate]").forEach(element => {
        const key = element.getAttribute("data-translate");
        if (translations[lang][key]) {
            element.innerHTML = translations[lang][key];
        }
    });

    // Actualizar la posición del interruptor
    document.getElementById("languageSwitch").checked = lang === "en";
}

// Aplicar el idioma guardado al cargar la página
document.addEventListener("DOMContentLoaded", () => {
    const savedLang = localStorage.getItem("selectedLanguage") || "es";
    applyLanguage(savedLang);

    // Evento de cambio de idioma con el switch
    document.getElementById("languageSwitch").addEventListener("change", (event) => {
        const newLang = event.target.checked ? "en" : "es";
        localStorage.setItem("selectedLanguage", newLang);
        applyLanguage(newLang);
    });
});
