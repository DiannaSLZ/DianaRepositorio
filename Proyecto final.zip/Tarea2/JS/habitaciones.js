document.addEventListener('DOMContentLoaded', () => {
  const habitacion = document.getElementById('habitacion');
  const paquete = document.getElementById('paquete');
  const precioResultado = document.getElementById('precioResultado');

  const preciosHabitaciones = {
      'Suite Deluxe': 30000,
      'Estándar con Rascador': 20000,
      'Habitación con Balcón': 25000
  };

  const preciosPaquetes = {
      'Todo Incluido (comida, juegos, vet)': 15000,
      'Solo Alojamiento': 0,
      'Paquete Relajación (masajes y música)': 8000
  };

  function calcularPrecio() {
      const hab = habitacion.value;
      const pack = paquete.value;

      if (hab && pack) {
          const precioTotal = preciosHabitaciones[hab] + preciosPaquetes[pack];
          precioResultado.textContent = `₡${precioTotal.toLocaleString()} por noche`;
      } else {
          precioResultado.textContent = 'Precio total.';
      }
  }

  habitacion.addEventListener('change', calcularPrecio);
  paquete.addEventListener('change', calcularPrecio);
});
