document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    let errorMessage = document.getElementById("error-message");
    
    if (username === "cenfo" && password === "123") {
        // Mostrar el modal de éxito
        let successModal = new bootstrap.Modal(document.getElementById("successModal"));
        successModal.show();

        // Esperar 3 segundos y redirigir a landing.html
        setTimeout(() => {
            window.location.href = "landing.html";
        }, 3000);
    } else {
        // Mostrar mensaje de error con animación
        errorMessage.classList.remove("d-none");
        errorMessage.classList.add("animate__animated", "animate__shakeX"); // Agregar animación de error

        // Ocultar el mensaje después de 2 segundos
        setTimeout(() => {
            errorMessage.classList.add("d-none");
            errorMessage.classList.remove("animate__animated", "animate__shakeX");
        }, 2000);
    }
});
