// Función para evaluar la encuesta y mostrar los resultados
function evaluarEncuesta() {
    // Recuperamos las respuestas de los campos de texto
    var r1 = document.getElementById('r1').value;
    var r2 = document.getElementById('r2').value;

    // Recuperamos las respuestas de las opciones de radio (Sí/No)
    var opinion = document.querySelector('input[name="opinion"]:checked');
    var opinion2 = document.querySelector('input[name="opinion2"]:checked');

    // Recuperamos las respuestas de los checkboxes
    var calidad = document.getElementById('calidad').checked ? 'Calidad de las instalaciones' : '';
    var atencion = document.getElementById('atencion').checked ? 'Atención personalizada' : '';
    var servicio = document.getElementById('servicio').checked ? 'Actividades recreativas para los gatos' : '';
    var redes = [];
    if (document.getElementById('radio').checked) redes.push('Internet');
    if (document.getElementById('facebook').checked) redes.push('Facebook');
    if (document.getElementById('instagram').checked) redes.push('Instagram');
    if (document.getElementById('referido').checked) redes.push('Recomendación de un amigo');
    if (document.getElementById('otro').checked) redes.push('Otro');

    // Comprobamos que las preguntas obligatorias están respondidas
    if (!r1 || !r2 || !opinion || !opinion2) {
        Swal.fire({
            icon: 'error',
            title: '¡Error!',
            text: 'Por favor, complete todas las preguntas obligatorias.',
        });
        return;
    }

    // Mostramos los resultados de la encuesta
    document.getElementById('res0').innerHTML = "Gracias por completar nuestra encuesta, los resultados son los siguientes:";
    document.getElementById('res1').innerHTML = "1. Lo que más destacó de la estadía: " + r1;
    document.getElementById('res2').innerHTML = "2. Lo que recomendaría a otros: " + r2;
    document.getElementById('res3').innerHTML = `3. Probabilidad de volver a visitarnos: ${opinion.value}<br>
                                                 4. Calificación de la atención: ${opinion2.value}<br>
                                                 5. Aspectos destacados: ${[calidad, atencion, servicio].filter(Boolean).join(', ')}<br>
                                                 6. Se enteró del hotel por: ${redes.join(', ')}`;
    
    // Limpiar el formulario después de mostrar los resultados
    limpiarFormulario();
}

// Función para limpiar el formulario
function limpiarFormulario() {
    document.getElementById('formulario').reset();
    document.getElementById('res0').innerHTML = "";
    document.getElementById('res1').innerHTML = "";
    document.getElementById('res2').innerHTML = "";
    document.getElementById('res3').innerHTML = "";
}


function evaluarEncuesta() {
    // Obtener los valores
    let r1 = document.getElementById("r1").value;
    let r2 = document.getElementById("r2").value;
    let opinion = document.querySelector('input[name="opinion"]:checked');
    let opinion2 = document.querySelector('input[name="opinion2"]:checked');

    if (!r1 || !r2 || !opinion || !opinion2) {
        Swal.fire({
            icon: "warning",
            title: "Faltan respuestas",
            text: "Por favor, completa todas las preguntas antes de enviar la encuesta."
        });
        return;
    }


    // Alerta de confirmación
    Swal.fire({
        icon: "success",
        title: "Encuesta enviada",
        text: "¡Gracias por tu opinión! 😊",
        confirmButtonColor: "#ed84d1"
    });
}
