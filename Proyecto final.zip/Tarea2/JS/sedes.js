function mostrarSede() {
    const sedes = {
        "San Jose": {
            nombre: "Sede San José",
            descripcion: "Nuestra sede en San José ofrece suites de lujo para gatos, con atención personalizada, juegos interactivos y cámaras en vivo para que puedas ver a tu mascota desde donde estés.",
            imagen: "imagenes/SJ.avif"
        },
        "Heredia": {
            nombre: "Sede Heredia",
            descripcion: "Ubicada en una zona tranquila rodeada de naturaleza, esta sede ofrece ambientes relajantes, aromaterapia felina y atención veterinaria 24/7.",
            imagen: "imagenes/Heredia.jpg"
        },
        "Cartago": {
            nombre: "Sede Cartago",
            descripcion: "La sede de Cartago cuenta con habitaciones con calefacción para los días frescos, además de amplias zonas de juegos internos y externos para el entretenimiento total de tu gato.",
            imagen: "imagenes/Cartago.jpg"
        },
        "Guanacaste": {
            nombre: "Sede Guanacaste",
            descripcion: "Disfruta de la sede más tropical del país. Rodeada de vegetación y aire puro, tu gato podrá disfrutar de vistas hermosas y mucha paz.",
            imagen: "imagenes/Guanacaste (1).jpg"
        },
        "Alajuela": {
            nombre: "Sede Alajuela",
            descripcion: "Con fácil acceso desde el aeropuerto, esta sede es ideal para viajes. Cuenta con transporte seguro desde y hacia tu domicilio.",
            imagen: "imagenes/Alajuela.jpg"
        }
    };

    const seleccion = document.getElementById("SedeSelect").value;
    const sedeInfo = document.getElementById("sedeInfo");
    const sedeNombre = document.getElementById("sedeNombre");
    const sedeDescripcion = document.getElementById("sedeDescripcion");
    const sedeImagen = document.getElementById("sedeImagen");

    if (sedes[seleccion]) {
        sedeNombre.textContent = sedes[seleccion].nombre;
        sedeDescripcion.textContent = sedes[seleccion].descripcion;
        sedeImagen.src = sedes[seleccion].imagen;
        sedeImagen.alt = sedes[seleccion].nombre;
        sedeInfo.style.display = "block";
    } else {
        sedeInfo.style.display = "none";
    }
}
