'use strict';

// Carga de la función init
window.addEventListener('load', init, false);

// Función inicial
function init() {
    // Declaración de elementos
    let nombre = document.getElementById('nombreTxt');
    let apellido = document.getElementById('apellidoTxt');
    let email = document.getElementById('emailTxt');
    let numero = document.getElementById('numberTxt');
    let mensaje = document.getElementById('mensajeTxt');
    let alerta = document.getElementById('mensajeAlert');
    let btnEnviar = document.getElementById('btnSend');
    let expressionEmail = /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/;

    // Función del botón Enviar
    btnEnviar.onclick = function() {
        nombre = nombreTxt.value;
        apellido = apellidoTxt.value;
        email = emailTxt.value;
        numero = numberTxt.value;
        mensaje = mensajeTxt.value;

        // Condicionales anidadas para validar cada campo del formulario
        if (nombre === '' && apellido === '' && email === '' && numero === '' && mensaje === '') {
            alerta.textContent = "Debe llenar todos los campos";
            alerta.classList.add('alertaRoja');
            alerta.classList.remove('alertaVerde');
        } else if (nombre === '') {
            alerta.textContent = "El campo nombre está vacío";
            alerta.classList.add('alertaRoja');
        } else if (apellido === '') {
            alerta.textContent = "El campo apellido está vacío";
            alerta.classList.add('alertaRoja');
        } else if (email === '') {
            alerta.textContent = "El campo email está vacío";
            alerta.classList.add('alertaRoja');
        } else if (!expressionEmail.test(email)) {
            alerta.textContent = "Email inválido";
            alerta.classList.add('alertaRoja');
        } else if (numero === '') {
            alerta.textContent = "El campo teléfono está vacío";
            alerta.classList.add('alertaRoja');
        } else if (mensaje === '') {
            alerta.textContent = "El campo mensaje está vacío";
            alerta.classList.add('alertaRoja');
        } else {
            // Si NO existe error en los campos validados, se envían los datos al servidor de correo
            alerta.textContent = 'Mensaje enviado';
            alerta.classList.add('alertaVerde');
            alerta.classList.remove('alertaRoja');

            // Envío del formulario con EmailJS
            emailjs.sendForm('service_q911jdr', 'template_0z9zxcj', 'form', 'hon6By-GD62E4Czty');

            // Carga de la función limpiar
            limpiar();
        }
    };

    function limpiar() {
        nombreTxt.value = '';
        apellidoTxt.value = '';
        emailTxt.value = '';
        numberTxt.value = '';
        mensajeTxt.value = '';
    }
}
function mostrarAlerta(mensaje, exito) {
    alerta.textContent = mensaje;
    if (exito) {
        alerta.classList.remove('alertaRoja');
        alerta.classList.add('alertaVerde');
        
        // Usar la transición de opacidad para desaparecer el mensaje después de 4 segundos
        setTimeout(function() {
            alerta.classList.add('hidden');  // Agregar la clase 'hidden' para que desaparezca suavemente
            setTimeout(function() {
                alerta.textContent = '';  // Limpiar el mensaje
                alerta.classList.remove('alertaVerde');  // Quitar la clase de éxito
                alerta.classList.remove('hidden');  // Eliminar la clase 'hidden'
            }, 500); // Esperar 500ms para que la transición de opacidad termine
        }, 4000); // 4000 ms = 4 segundos
    } else {
        alerta.classList.remove('alertaVerde');
        alerta.classList.add('alertaRoja');
    }
}
