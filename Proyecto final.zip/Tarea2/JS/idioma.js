const textos = {
  es: {
    "bienvenida-titulo": "Bienvenidos al Mejor Hotel para Gatos",
    "bienvenida-texto": "En Purrfection, tu gato disfrutará de una estadía cómoda, segura y llena de diversión mientras tú viajas con tranquilidad.",
    "card1-titulo": "Habitaciones Purrfectas",
    "card1-texto": "Amplias, confortables con juguetes y camitas suaves.",
    "card2-titulo": "Alimentación Premium",
    "card2-texto": "Menú especial adaptado a las necesidades de cada gato.",
    "card3-titulo": "Diversión Asegurada",
    "card3-texto": "Zonas de juegos purrfectas para extrema diversión.",
    "historia-tab": "Historia",
    "mision-tab": "Misión",
    "vision-tab": "Visión",
    "historia-texto": "En 2021, nació Purrfection con el objetivo de brindar a los gatos un hogar temporal lleno de amor...",
    "mision-texto": "Brindar un servicio de hospedaje cómodo y seguro a nuestros amigos felinos...",
    "vision-texto": "Ser el hotel para gatos más reconocido a nivel nacional por nuestro cariño y profesionalismo...",
    "footer-texto": "Síguenos en nuestras redes:",
    "Inicio": "Inicio",
    "serviciosDropdown": "Servicios"
  },
  en: {
    "bienvenida-titulo": "Welcome to the Best Hotel for Cats",
    "bienvenida-texto": "At Purrfection, your cat will enjoy a cozy, safe, and fun stay while you travel with peace of mind.",
    "card1-titulo": "Purrfect Rooms",
    "card1-texto": "Spacious and comfy with toys and soft beds.",
    "card2-titulo": "Premium Feeding",
    "card2-texto": "Special menu tailored to each cat's needs.",
    "card3-titulo": "Guaranteed Fun",
    "card3-texto": "Purrfect play areas for extreme fun.",
    "historia-tab": "Our Story",
    "mision-tab": "Mission",
    "vision-tab": "Vision",
    "historia-texto": "In 2021, Purrfection was born to offer cats a loving temporary home...",
    "mision-texto": "To provide a safe and comfortable stay for our feline friends...",
    "vision-texto": "To be the most recognized cat hotel nationwide for our care and professionalism...",
    "footer-texto": "Follow us on social media:",
    "Inicio":"Home",
    "serviciosDropdown": "Services"
  }
};

document.addEventListener("DOMContentLoaded", () => {
  const selector = document.getElementById("idioma-select");

  if (selector) {
    selector.addEventListener("change", function () {
      const lang = this.value;
      for (const id in textos[lang]) {
        const elemento = document.getElementById(id);
        if (elemento) elemento.innerText = textos[lang][id];
      }
    });
  }
});