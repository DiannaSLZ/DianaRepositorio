  function opciones(evt, tabName) {
    // Oculta todo el contenido de las pestañas
    let tabcontent = document.getElementsByClassName("tabcontent");
    for (let i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }

    // Quita la clase activa de todos los botones
    let tablinks = document.getElementsByClassName("tablinks");
    for (let i = 0; i < tablinks.length; i++) {
      tablinks[i].classList.remove("active");
    }

    // Muestra la pestaña seleccionada y marca el botón como activo
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.classList.add("active");
  }

  $(document).ready(function () {
    $(".owl-carousel").owlCarousel({
        items: 4,
      lazyLoad: true,
      autoplay: true,
      autoplayTimeout: 3000,
      loop: true,
      nav: true,
      navText: ["←", "→"],
      dots: false,
      smartSpeed: 600,
      responsive: {
        0: { items: 1 },
        600: { items: 2 },
        1000: { items: 4 }
      }
    });
  });
