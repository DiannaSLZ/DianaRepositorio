window.addEventListener('DOMContentLoaded', () => {
  ocultarTodo();
});

document.getElementById('menuOpciones').addEventListener('change', filtrarContenido);
document.getElementById('buscadorTexto').addEventListener('input', filtrarContenido);

function ocultarTodo() {
  document.querySelectorAll('.galeriaFotos').forEach(galeria => {
    galeria.style.display = 'none';
    galeria.querySelectorAll('.col-md-4').forEach(tarjeta => {
      tarjeta.style.display = 'none';
    });
  });
}

function filtrarContenido() {
  const categoria = document.getElementById('menuOpciones').value;
  const texto = document.getElementById('buscadorTexto').value.toLowerCase();
  const galerias = document.querySelectorAll('.galeriaFotos');

  // 👉 Si no hay texto ni categoría, ocultar todo
  if (categoria === "" && texto === "") {
    ocultarTodo();
    return;
  }

  galerias.forEach(galeria => {
    const categoriaGaleria = galeria.getAttribute('data-category');
    const tarjetas = galeria.querySelectorAll('.col-md-4');
    let algunaVisible = false;

    tarjetas.forEach(tarjeta => {
      const titulo = tarjeta.querySelector('h3').textContent.toLowerCase();
      const coincideCategoria = (categoria === "" || categoria === categoriaGaleria);
      const coincideTexto = (texto === "" || titulo.includes(texto));

      if (coincideCategoria && coincideTexto) {
        tarjeta.style.display = ""; // Mostrar tarjeta con estilo por defecto
        algunaVisible = true;
      } else {
        tarjeta.style.display = "none";
      }
    });

    // Mostrar galería solo si tiene al menos una tarjeta visible
    galeria.style.display = algunaVisible ? "block" : "none";
  });
}

fetch('data/alimentacion.json')
  .then(response => response.json())
  .then(data => {
    // aquí puedes trabajar con el JSON, por ejemplo: mostrar productos
    console.log(data);
  })
  .catch(error => console.error('Error al cargar el JSON:', error));
