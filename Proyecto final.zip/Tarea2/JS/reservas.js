document.addEventListener('DOMContentLoaded', () => {
    emailjs.init('hon6By-GD62E4Czty'); // Tu ID de usuario
  
    const form = document.getElementById('reservaForm');
  
    form.addEventListener('submit', function (e) {
      e.preventDefault();
  
      // Campos
      const email = document.getElementById('emailReserva').value.trim();
      const entrada = document.getElementById('entrada').value;
      const salida = document.getElementById('salida').value;
  
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const hoy = new Date();
      hoy.setHours(0, 0, 0, 0); // Ignorar hora, comparar solo fecha
  
      // Validaciones
      if (!emailRegex.test(email)) {
        Swal.fire('Correo inválido', 'Introduce un correo electrónico válido.', 'error');
        return;
      }
  
      if (new Date(entrada) < hoy) {
        Swal.fire('Fecha inválida', 'La fecha de ingreso no puede ser en el pasado.', 'warning');
        return;
      }
  
      if (new Date(entrada) >= new Date(salida)) {
        Swal.fire('Fechas inválidas', 'La fecha de salida debe ser posterior a la de ingreso.', 'error');
        return;
      }
  
      // Cálculo del precio
      const tarifaPorNoche = 1000; // Precio por noche en
      const fechaEntrada = new Date(entrada);
      const fechaSalida = new Date(salida);
      const tiempoEstancia = Math.ceil((fechaSalida - fechaEntrada) / (1000 * 60 * 60 * 24));
      const precioTotal = tiempoEstancia * tarifaPorNoche;
  
      const precioFormateado = new Intl.NumberFormat('es-CR', {
        style: 'currency',
        currency: 'CRC'
      }).format(precioTotal);
  
      // Confirmación antes de enviar
      Swal.fire({
        title: 'Confirmar reserva',
        html: `Estancia de <b>${tiempoEstancia} noches</b><br>Total: <b>${precioFormateado}</b><br>¿Deseas continuar?`,
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Sí, reservar',
        cancelButtonText: 'Cancelar'
      }).then((result) => {
        if (result.isConfirmed) {
          // Envío del formulario
          emailjs.sendForm('service_q911jdr', 'template_joh1qqr', '#reservaForm', 'hon6By-GD62E4Czty')
            .then(() => {
              Swal.fire('¡Reserva confirmada!', 'Te hemos enviado un email con los detalles. 😺', 'success');
              form.reset();
            })
            .catch((error) => {
              console.error('Error al enviar:', error);
              Swal.fire('Error', 'No se pudo enviar el correo. Intenta de nuevo más tarde.', 'error');
            });
        }
      });
    });
  });
  
  document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("reservaForm");
    const entrada = document.getElementById("entrada");
    const salida = document.getElementById("salida");
    const habitacion = document.getElementById("habitacion");
    const mostrarPrecio = document.getElementById("mostrarPrecio");
    const reservas = [];
  
    function calcularPrecio() {
      const fechaInicio = new Date(entrada.value);
      const fechaFin = new Date(salida.value);
      const tipo = habitacion.value;
  
      if (fechaInicio && fechaFin && tipo && fechaFin > fechaInicio) {
        const dias = Math.ceil((fechaFin - fechaInicio) / (1000 * 60 * 60 * 24));
        let precioPorNoche = 0;
  
        switch (tipo) {
          case "Cueva acogedora":
            precioPorNoche = 15;
            break;
          case "Sala de juegos con vista":
            precioPorNoche = 25;
            break;
          case "Suite de lujo con rascador":
            precioPorNoche = 40;
            break;
        }
  
        const total = dias * precioPorNoche;
        mostrarPrecio.innerHTML = `<strong>Precio estimado:</strong> $${total} USD por ${dias} noches.`;
  
        // Guardar la reserva
        reservas.push({
          tipo,
          dias,
          total
        });
  
        localStorage.setItem("reservas", JSON.stringify(reservas));
      } else {
        mostrarPrecio.innerHTML = "";
      }
    }
  
    entrada.addEventListener("change", calcularPrecio);
    salida.addEventListener("change", calcularPrecio);
    habitacion.addEventListener("change", calcularPrecio);
  
    // Filtro de reservas
    document.getElementById("btnFiltrar").addEventListener("click", () => {
      const filtro = document.getElementById("filtroHabitacion").value;
      const lista = document.getElementById("listaFiltrada");
      lista.innerHTML = "";
  
      const reservasGuardadas = JSON.parse(localStorage.getItem("reservas")) || [];
  
      const filtradas = filtro
        ? reservasGuardadas.filter(r => r.tipo === filtro)
        : reservasGuardadas;
  
      if (filtradas.length === 0) {
        lista.innerHTML = "<li class='list-group-item'>No hay reservas para esta habitación.</li>";
      } else {
        filtradas.forEach(r => {
          const item = document.createElement("li");
          item.className = "list-group-item";
          item.textContent = `Hab: ${r.tipo} - ${r.dias} noches - Total: $${r.total}`;
          lista.appendChild(item);
        });
      }
    });
  
    // Validación del form (opcional si usás Bootstrap validation)
    //form.addEventListener("submit", (e) => {
        e.preventDefault();
        if (!form.checkValidity()) {
          form.classList.add("was-validated");
          return;
        }
        form.reset();
        mostrarPrecio.innerHTML = "";
      });
  