function changeColor(image) {
    document.getElementById('car-image').src = image;

    // Quitar la selección de todos los botones
    let buttons = document.querySelectorAll('.color-option');
    buttons.forEach(btn => btn.classList.remove('selected'));

    // Agregar la selección al color elegido
    event.target.classList.add('selected');
}
