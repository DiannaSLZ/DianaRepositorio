function mostrarMuseo() {
    const museos = {
        nacional: {
            nombre: "Museo Nacional de Costa Rica",
            descripcion: "El Museo Nacional de Costa Rica se encuentra ubicado en la ciudad de San José. Fue creado el 4 de mayo de 1887 por medio del acuerdo Nº 60, durante la administración del presidente Bernardo Soto Alfaro. La actual localización del museo es el antiguo Cuartel Bellavista",
            imagen: "Imagenes/MuseoCR.jpg"
        },
        oro: {
            nombre: "Museo del Oro Precolombino",
            descripcion: "Museo del Oro Precolombino o Museo del Oro, es un museo histórico, arqueológico y cultural ubicado en San José, capital de Costa Rica. Se encuentra localizado en un edificio subterráneo bajo la Plaza de la Cultura, Posee una extraordinaria colección de objetos elaborados en oro, los cuales reflejan la cosmovisión, la estructura social y la orfebrería de los pueblos precolombinos que ocuparon el actual territorio costarricense.",
            imagen: "Imagenes/MuseoOroCR.jpg"
        },
        jade: {
            nombre: "Museo de Jade y Arte Precolombino",
            descripcion: "El Museo del Jade y de la Cultura Precolombina, llamado simplemente Museo del Jade, es un museo histórico, cultural y arqueológico ubicado en San José, Costa Rica,Resguarda una colección arqueológica conformada por una amplia gama de artefactos de cerámica, hueso, madera, concha y piedra como estatuaria, metates, manos de moler y otros, sin embargo, su principal atractivo es la enorme cantidad de piezas arqueológicas confeccionadas con piedras semipreciosas conocidas en su conjunto como jade, colección considerada como la más grande del mundo con respecto a esta piedra preciosa.",
            imagen: "Imagenes/museoJadeCR.jpg"
        },
        ninos: {
            nombre: "Museo de los Niños",
            descripcion: "El Museo de los Niños es el único museo interactivo de Costa Rica que busca la formación y diversión de niños y niñas de todas las edades. Fue inaugurado en 1994 como parte del Centro Costarricense de la Ciencia y La Cultura y representa la parte más conocida del mism",
            imagen: "Imagenes/MuseoNinosCR.jpg"
        },
        juanSantamaria: {
            nombre: "Museo Histórico Cultural Juan Santamaría",
            descripcion: "El Museo Histórico Cultural Juan Santamaría, llamado también Museo Juan Santamaría, está ubicado en la ciudad de Alajuela, Costa Rica.Dedicado al héroe nacional Juan Santamaría y la Campaña Nacional de 1856.",
            imagen: "Imagenes/MuseoJuanSantamaríaCR.jpg"
        }
    };

    let seleccion = document.getElementById("museoSelect").value;
    let museoInfo = document.getElementById("museoInfo");
    let museoNombre = document.getElementById("museoNombre");
    let museoDescripcion = document.getElementById("museoDescripcion");
    let museoImagen = document.getElementById("museoImagen");

    if (seleccion in museos) {
        museoNombre.textContent = museos[seleccion].nombre;
        museoDescripcion.textContent = museos[seleccion].descripcion;
        museoImagen.src = museos[seleccion].imagen;
        museoImagen.alt = museos[seleccion].nombre;
        museoInfo.style.display = "block";
    } else {
        museoInfo.style.display = "none";
    }
}
