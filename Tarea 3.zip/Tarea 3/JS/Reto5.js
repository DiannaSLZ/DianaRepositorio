// Objeto con los modelos y sus respectivas imágenes
const televisores = {
    samsung: {
        "Crystal UHD": "Imagenes/SamsungCrystalUHD4K50.webp",
        "Neo QLED": "Imagenes/SamsungNeoQLED55.jpg"
    },
    lg: {
        "OLED 4K": "Imagenes/LGOLEDevoC365.jpg",
        "NanoCell": "Imagenes/LGUHDAIThinQ75.jpg"
    },
    sony: {
        "Bravia XR": "Imagenes/SonyBRAVIAXR85.jpg",
        "X90L": "Imagenes/SonyX90LFull ArrayLED65.jpg"
    }
};

// Función para cargar modelos según la marca seleccionada
function cargarModelos() {
    let marca = document.getElementById("marca").value;
    let modeloSelect = document.getElementById("modelo");
    
    // Limpiar modelos anteriores
    modeloSelect.innerHTML = '<option value="">-- Seleccionar modelo --</option>';

    if (marca && televisores[marca]) {
        for (let modelo in televisores[marca]) {
            let option = document.createElement("option");
            option.value = modelo;
            option.textContent = modelo;
            modeloSelect.appendChild(option);
        }
    }
}

// Función para calcular la cuota y mostrar la imagen del televisor
function calcularCuota() {
    let marca = document.getElementById("marca").value;
    let modelo = document.getElementById("modelo").value;
    let plazo = parseInt(document.getElementById("plazo").value);
    let imgTv = document.getElementById("tv-image");
    let cuotaTexto = document.getElementById("cuota");

    // Validaciones
    if (!marca || !modelo || !plazo) {
        alert("Por favor, seleccione una marca, un modelo y un plazo válido.");
        return;
    }

    // Simulación de precio (puedes cambiar los valores según prefieras)
    let precios = {
        "Crystal UHD": 500,
        "Neo QLED": 800,
        "OLED 4K": 900,
        "NanoCell": 750,
        "Bravia XR": 1100,
        "X90L": 950
    };

    let precio = precios[modelo];
    let cuota = (precio / plazo).toFixed(2);

    // Mostrar resultado
    cuotaTexto.innerHTML = `Cuota mensual: $${cuota}`;
    
    // Mostrar la imagen correspondiente
    imgTv.src = televisores[marca][modelo];
    imgTv.style.display = "block"; 
}
