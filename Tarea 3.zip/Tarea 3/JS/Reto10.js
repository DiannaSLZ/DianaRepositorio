// Datos de empleados con sus cédulas
const empleados = [
    { cedula: '109110338', nombre: 'Sofía', apellidos: 'Ramírez Castro', foto: 'Imagenes/Sofia.png', lugar: 'San Jose' },
    { cedula: '209110338', nombre: 'Diego', apellidos: 'Fernández Mora', foto: 'Imagenes/Diego.png', lugar: 'Cartago' },
    { cedula: '309110338', nombre: 'Valentina', apellidos: 'Gómez Rojas', foto: 'Imagenes/Valentina.png', lugar: 'Heredia' },
    { cedula: '409110338', nombre: 'Mateo', apellidos: 'López Salazar', foto: 'Imagenes/Mateo.png', lugar: 'Alajuela' },
    { cedula: '509110338', nombre: 'Camila', apellidos: 'Hernández Soto', foto: 'Imagenes/Camila.png', lugar: 'Puntarenas' }
];

document.getElementById('buscar').addEventListener('click', function () {
    const cedula = document.getElementById('cedula').value.trim();

    // Validación de cédula vacía
    if (!cedula) {
        alert('Por favor, ingrese un número de cédula.');
        return;
    }

    // Buscar el empleado en la lista
    const empleado = empleados.find(emp => emp.cedula === cedula);

    // Mostrar resultado en la página
    const resultadoDiv = document.getElementById('resultado');

    if (empleado) {
        resultadoDiv.innerHTML = `
            <h3>Resultado de la búsqueda:</h3>
            <p><strong>Nombre:</strong> ${empleado.nombre} ${empleado.apellidos}</p>
            <p><strong>Lugar:</strong> ${empleado.lugar}</p>
            <img src="${empleado.foto}" alt="Foto del empleado" />
        `;
    } else {
        resultadoDiv.innerHTML = `<p id="usuarioNoExiste">El usuario NO existe.</p>`;
    }
});

