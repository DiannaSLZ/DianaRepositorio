// Arreglo para almacenar estudiantes
let estudiantes = [];

// Función para agregar un estudiante
function agregarEstudiante() {
    let nombre = document.getElementById("nombre").value.trim();
    let apellidos = document.getElementById("apellidos").value.trim();
    let nota1 = parseFloat(document.getElementById("nota1").value);
    let nota2 = parseFloat(document.getElementById("nota2").value);
    let nota3 = parseFloat(document.getElementById("nota3").value);

    // Validación de campos
    if (nombre === "" || apellidos === "" || isNaN(nota1) || isNaN(nota2) || isNaN(nota3)) {
        alert("Por favor, complete todos los campos correctamente.");
        return;
    }

    // Crear objeto estudiante
    let estudiante = {
        nombreCompleto: `${nombre} ${apellidos}`,
        notas: [nota1, nota2, nota3]
    };

    // Agregar al arreglo
    estudiantes.push(estudiante);

    // Agregar opción al select
    let select = document.getElementById("listaEstudiantes");
    let option = document.createElement("option");
    option.value = estudiantes.length - 1; // Índice del estudiante
    option.textContent = estudiante.nombreCompleto;
    select.appendChild(option);

    // Limpiar campos
    document.getElementById("nombre").value = "";
    document.getElementById("apellidos").value = "";
    document.getElementById("nota1").value = "";
    document.getElementById("nota2").value = "";
    document.getElementById("nota3").value = "";

    alert("Estudiante agregado correctamente.");
}

// Función para calcular el promedio de notas
function calcularPromedio() {
    let select = document.getElementById("listaEstudiantes");
    let index = select.value;

    if (index === "") {
        alert("Por favor, seleccione un estudiante.");
        return;
    }

    // Obtener estudiante seleccionado
    let estudiante = estudiantes[index];
    let promedio = (estudiante.notas.reduce((a, b) => a + b, 0) / estudiante.notas.length).toFixed(2);

    // Mostrar resultado
    document.getElementById("resultado").textContent = `📌 ${estudiante.nombreCompleto} tiene un promedio de: ${promedio}`;
}
