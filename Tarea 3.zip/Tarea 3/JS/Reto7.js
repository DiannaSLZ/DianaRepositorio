function mostrarDescripcion(objeto) {
    const descripciones = {
        reloj: "⌚ **Reloj:** Dispositivo que mide y muestra el tiempo, esencial en cualquier oficina.",
        calculadora: "🧮 **Calculadora:** Herramienta indispensable para operaciones matemáticas rápidas.",
        lupa: "🔍 **Lupa:** Útil para examinar detalles pequeños en documentos y objetos.",
        boligrafo: "✍ **Bolígrafo:** Instrumento de escritura esencial para tomar notas y firmar documentos.",
        tabla: "📋 **Tabla:** Superficie donde se colocan documentos y herramientas de trabajo."
    };

    // Mostrar la descripción en el div
    document.getElementById("descripcion").innerHTML = descripciones[objeto];
    document.getElementById("descripcion").style.display = "block";
}
