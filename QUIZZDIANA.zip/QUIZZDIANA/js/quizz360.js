// Obtener una referencia al contenedor donde se mostrará la escena 3D 
var container = document.querySelector('#container_principal');

// Cargar la foto 360
var panorama = new PANOLENS.ImagePanorama('imagenes/shot-panoramic-composition-bedroom.jpg');

// Zona 1 interactiva (infospot1) - Cuadro de información
var infospot1 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot1.position.set(-500, -105, -305);
infospot1.addHoverText('Esta es la entrada principal de la habitación, equipada con una cerradura digital para mayor seguridad.');
infospot1.element.innerHTML = `
    <div style="background: rgba(0, 0, 0, 0.8); color: white; padding: 10px; border-radius: 5px; max-width: 250px;">
        Esta es la entrada principal de la habitación,equipada con una cerradura digital para mayor seguridad."
    </div>`;
panorama.add(infospot1);

// Zona 2 interactiva (infospot2) - Cuadro de información
var infospot2 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot2.position.set(-314, -226, -500);
infospot2.addHoverText('Lámpara de noche con luz adaptable y sensor táctil. Puedes ajustar la intensidad con un solo toque.', -60);
infospot2.element.innerHTML = `
    <div style="background: rgba(0, 0, 0, 0.8); color: white; padding: 10px; border-radius: 5px; max-width: 250px;">
        Lámpara de noche con luz adaptable y sensor táctil. Puedes ajustar la intensidad con un solo toque.
    </div>`;
panorama.add(infospot2);

// Zona 3 interactiva (infospot3) - Cuadro de información
var infospot3 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot3.position.set(-7, -155, -500);
infospot3.addHoverText('Almohadas de tela de lino con relleno de espuma viscoelástica. Diseñadas para brindar máximo confort durante el descanso', -60);
infospot3.element.innerHTML = `
    <div style="background: rgba(0, 0, 0, 0.8); color: white; padding: 10px; border-radius: 5px; max-width: 250px;">
        Almohadas de tela de lino con relleno de espuma viscoelástica. Diseñadas para brindar máximo confort durante el descanso
    </div>`;
panorama.add(infospot3);

// Zona 4 interactiva (infospot4) - Imagen
var infospot4 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot4.position.set(432 ,-379 , -500);
infospot4.addHoverText('Colcha suave y caliente, hecha con fibras de algodón de alta calidad. Ideal para noches frías.', -60);
infospot4.element.innerHTML = `
    <div style="background-color: rgba(0, 0, 0, 0.8); color: white; border-radius: 5px; padding: 10px; font-size: 14px; width: 250px;">
        Colcha suave y caliente, hecha con fibras de algodón de alta calidad. Ideal para noches frías.
        <br><br>
        <img src="imagenes/colcha.jpeg" alt="colcha" style="max-width: 100%; height: auto; border-radius: 5px;">
    </div>`;
panorama.add(infospot4);

// Zona 5 interactiva (infospot5) - Audio
var infospot5 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot5.position.set(500 ,-116 , 113);
infospot5.addHoverText('Sillón de diseño ergonómico, perfecto para relajarse mientras escuchas los sonidos de la naturaleza.', -60);
infospot5.element.innerHTML = `
    <div style="color:#000; border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">
        <audio controls>
            <source src="audio/jaynrox-naturaleza-282177.mp3" type="audio/mpeg">
        </audio>
    </div>`;
panorama.add(infospot5);

// Zona 6 interactiva (infospot6) - Video
var infospot6 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot6.position.set(-54 ,-174 , 500);
infospot6.addHoverText('Ver video', -60);
infospot6.element.innerHTML = `
    <div>
        <iframe width="720" height="480" src="https://www.youtube.com/embed/5Mv5xoz08Mo" frameborder="0" allowfullscreen></iframe>
    </div>`;
panorama.add(infospot6);

// Zona 7 interactiva (infospot7) - Cuadro de información
var infospot7 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot7.position.set(209 ,-20 , 500);
infospot7.addHoverText('Puerta corrediza de vidrio templado que da acceso a la terraza. Disfruta de una vista panorámica espectacular.');
infospot7.element.innerHTML = `
    <div style="background: rgba(0, 0, 0, 0.8); color: white; padding: 10px; border-radius: 5px; max-width: 250px;">
        Puerta corrediza de vidrio templado que da acceso a la terraza. Disfruta de una vista panorámica espectacular.
    </div>`;
panorama.add(infospot7);

// Zona 8 interactiva (infospot8) - Cuadro de información
var infospot8 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot8.position.set(500 ,349 , -48);
infospot8.addHoverText('Tragaluz panorámico');
infospot8.element.innerHTML = `
    <div style="background: rgba(0, 0, 0, 0.8); color: white; padding: 10px; border-radius: 5px; max-width: 250px;">
         Tragaluz panorámico que permite la entrada de luz natural durante el día, mejorando la iluminación y reduciendo el consumo eléctrico. 
        Su vidrio templado ofrece protección contra impactos y filtros UV para evitar el sobrecalentamiento de la habitación.
    </div>`;
panorama.add(infospot8);

// Zona 9 interactiva (infospot9) - Cuadro de información
var infospot9 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot9.position.set(-316 ,-295 , 500);
infospot9.addHoverText('Guarda ropa de madera con múltiples compartimentos y organizadores internos. Perfecto para mantener el orden.');
infospot9.element.innerHTML = `
    <div style="background: rgba(0, 0, 0, 0.8); color: white; padding: 10px; border-radius: 5px; max-width: 250px;">
        Guarda ropa de madera con múltiples compartimentos y organizadores internos. Perfecto para mantener el orden.
    </div>`;
panorama.add(infospot9);

// Zona 10 interactiva (infospot10) - Cuadro de información
var infospot10 = new PANOLENS.Infospot(50, PANOLENS.DataImage.Info);
infospot10.position.set(-500 ,-112 , 191);
infospot10.addHoverText('Baño privado con acabados modernos');
infospot10.element.innerHTML = `
    <div style="background: rgba(0, 0, 0, 0.8); color: white; padding: 10px; border-radius: 5px; max-width: 250px;">
        Baño privado con acabados modernos
    </div>`;
panorama.add(infospot10);

// Crear el visor y agregar la escena
var viewer = new PANOLENS.Viewer({
    container: container,
    output: 'fullscreen',
    autoHideInfospot: false
});

viewer.add(panorama);
